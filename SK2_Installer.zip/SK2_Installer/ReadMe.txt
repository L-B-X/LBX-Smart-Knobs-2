Load ./SK2_Install/LBX_SK2_installer.lua script into Reaper's action list.
Run LBX_SK2_installer.lua script in Reaper.

If SWS and JS extensions ok -

Click on LOCATE INSTALL.SK2 FILE button.

Locate and load the install.sk2 file.

Click on INSTALL SK2 button.

--------------------------------------------------------------------

Changes from previous BETA:

Main script GUI title changed to 'Smart Knobs 2' - so any hide scripts may need updating to work with the new window title.

The new resources folder will be named: SmartKnobs2_DATA
The new main script file will be named: LBX_SmartKnobs2.lua
The new pop up script file will be named: LBX_SmartKnobs2_Properties.lua
The new CM Creator script file will be named: LBX_SmartKnobs2_ControlMapCreator.lua
The retro rec one has not been renamed
The new Faderbox jsfx is named: LBX_SKCTL
The new SKCC3 jsfx is named: LBX_SKCC
The new ForRetroRec(MIDI) jsfx is named: LBX_RRMIDI
Everything else is named as before.